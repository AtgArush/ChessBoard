
import React from "react"
import ChessCard from "./chessRow"

const App = () => {
    return(
        <div>
          <ChessCard />
        </div>
    )
}

export default App;
