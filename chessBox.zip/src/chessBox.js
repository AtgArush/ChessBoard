import React from 'react'
import "./chessRow.css"
function MyChess({styler}) {
    return (
        <div>
            <div className={styler}>
                <div className="box">
                </div>
                <div className="box">
                </div>
                <div className="box">
                </div>
                <div className="box">
                </div>
                <div className="box">
                </div>
                <div className="box">
                </div>
                <div className="box">
                </div>
                <div className="box">
                </div>
        </div>
        </div>
    )
}

export default MyChess
